def ftoc(f)

	c=(f - 32) * 5/9

	return c
end

def ctof(c)
	cbis=c.to_f
	f=(cbis * 9/5)+ 32
	#if c==37 then f=01*98.6 end 

	return f
end