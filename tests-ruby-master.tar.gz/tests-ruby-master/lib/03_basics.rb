def who_is_bigger(*values)
 values.max
end