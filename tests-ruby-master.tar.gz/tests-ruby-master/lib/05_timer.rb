def time_string(time)
  return Time.at(time).utc.strftime ("%H:%M:%S") 
end
